export const URL = {
  POPULAR: process.env.URL + "popular/",
  RECENT: process.env.URL + "recentlyadded/",
  DETAILS: process.env.URL + "details/",
  EPLINK: process.env.URL + "watching/",
  GENRES: process.env.URL + "genre/",
  SEARCH: process.env.URL + "search/",
};
