import { MyAction } from "../actions/actions";
export const makeLoadingFalse = () => {
  return { type: MyAction.FALSELOADING };
};
